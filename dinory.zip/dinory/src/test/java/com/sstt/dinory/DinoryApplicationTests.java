package com.sstt.dinory;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DinoryApplicationTests {

	@Test
	void contextLoads() {
	}

}
