package com.sstt.dinory;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DinoryApplication {

	public static void main(String[] args) {
		SpringApplication.run(DinoryApplication.class, args);
	}

}
